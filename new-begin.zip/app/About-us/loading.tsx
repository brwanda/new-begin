import Image from "next/image"


function HomePage() {
  return (
    <div className="container py-3 pt-5">
        <h3 className="text-center">Loading</h3>

    </div>
  )
}

export default HomePage
