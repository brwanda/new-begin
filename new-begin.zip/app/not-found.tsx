import Home from "@/components/404";

import Footer from "@/components/footer";



function HomePage() {
  return (
    <div>
      <Home />
      <Footer />

    </div>
  )
}

export default HomePage
