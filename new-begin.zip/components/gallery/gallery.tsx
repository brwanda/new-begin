import Image from 'next/image';
import Link from 'next/link';

const Gallery = () => {
  return (
    <div className='container  max-w-7xl mx-auto bg-white py-12'>
         <div className="text-center py-3">
            <h2 className="text-base font-semibold uppercase tracking-wide text-gray-600">Last Events</h2>
            <p className="mt-1 text-4xl font-extrabold sm:text-5xl sm:tracking-tight lg:text-6xl">Discover Gallery</p>
            <div className="mt-5 max-w-md mx-auto">
              <div className="text-center">
                <span className="inline-block text-gray-600 slok px-4 py-1 rounded-full text-sm font-semibold tracking-wide">
                  ALL
                </span>
              </div>
            </div>
          </div>
    <div className="now">
      <div className="gallery">
        

            <Link href={'/Image/rectangle-16-xeZ'} >

          <Image
            src="/rectangle-16-xeZ.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
      
        <Link href={'/Image/rectangle-16-RVF'} >
          <Image
            src="/rectangle-16-RVF.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
          <Link href={'/Image/rectangle-15-38Z'} >
          <Image
            src="/rectangle-15-38Z.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
          
          <Link href={'/Image/rectangle-16-eWh'} >
          <Image
            src="/rectangle-16-eWh.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
          <Link href={'/Image/rectangle-16-fAV'} >
       
          <Image
            src="/rectangle-16-fAV.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
      </Link>
      <Link href={'/Image/rectangle-17-2RK'} >
       
          <Image
            src="/rectangle-17-2RK.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
          <Link href={'/Image/rectangle-16-fAV'} >
       
      
          <Image
            src="/rectangle-16-fAV.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
          <Link href={'/Image/rectangle-17-2RK'} >
      
      
          <Image
            src="/rectangle-17-2RK.png"
            alt=""
            layout="responsive"
            width={100}
            height={100}
            className="rounded-lg nowimage"
            style={{width:'95%', height: '100%', objectFit: 'contain'}}
            sizes='60vw' priority
          />
          </Link>
        </div>
        
      
      </div>
      
    </div>

  );
};

export default Gallery;
